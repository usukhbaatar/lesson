<?php

class Model_DbTable_Activation extends Zend_Db_Table_Abstract {
	protected $_name = 'activation';
}
