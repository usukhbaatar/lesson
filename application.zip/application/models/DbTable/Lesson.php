<?php

class Model_DbTable_Lesson extends Zend_Db_Table_Abstract {
	protected $_name = 'lesson';
}
