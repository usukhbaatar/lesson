<?php

class Model_DbTable_Learn extends Zend_Db_Table_Abstract {
	protected $_name = 'learn';
}
