<?php

class Model_DbTable_Topic extends Zend_Db_Table_Abstract {
	protected $_name = 'topic';
}
