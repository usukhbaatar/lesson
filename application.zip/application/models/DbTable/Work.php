<?php

class Model_DbTable_Work extends Zend_Db_Table_Abstract {
	protected $_name = 'work';
}
