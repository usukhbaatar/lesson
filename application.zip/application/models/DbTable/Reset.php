<?php
	class Model_DbTable_Reset extends Zend_Db_Table_Abstract{
		protected $_name = 'resetpassword';
	}
