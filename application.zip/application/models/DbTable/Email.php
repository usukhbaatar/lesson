<?php

class Model_DbTable_Email extends Zend_Db_Table_Abstract {
	protected $_name = 'email';
}
