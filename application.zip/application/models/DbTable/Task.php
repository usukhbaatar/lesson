<?php

class Model_DbTable_Task extends Zend_Db_Table_Abstract {
	protected $_name = 'task';
}
