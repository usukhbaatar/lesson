<?php

class Model_DbTable_Class extends Zend_Db_Table_Abstract {
	protected $_name = 'class';
}
