<?php

class Model_DbTable_Request extends Zend_Db_Table_Abstract {
	protected $_name = 'request';
}
