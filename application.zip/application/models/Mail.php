<?php

class Model_Mail {
	public function send($subject, $body, $email) {
		$config = array('ssl' => 'tls',
	                'auth' => 'login',
	                'username' => 'osohoo02@gmail.com',
	                'password' => 'leader of world 1');
		$transport = new Zend_Mail_Transport_Smtp('smtp.gmail.com', $config);
	    
	    $mail = new Zend_Mail();
	    $mail->setBodyHtml($body);
	    $mail->setFrom('osohoo02@gmail.com');
	    $mail->addTo($email);
	    $mail->setSubject($subject);
	    $mail->send($transport);
	}

}
